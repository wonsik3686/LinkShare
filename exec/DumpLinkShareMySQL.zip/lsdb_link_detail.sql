-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: linkshare-01-db.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: lsdb
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `link_detail`
--

DROP TABLE IF EXISTS `link_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `link_detail` (
  `linkid` int NOT NULL AUTO_INCREMENT,
  `boxid` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` text,
  `thumbnail` varchar(255) DEFAULT NULL,
  `url` text,
  PRIMARY KEY (`linkid`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_detail`
--

LOCK TABLES `link_detail` WRITE;
/*!40000 ALTER TABLE `link_detail` DISABLE KEYS */;
INSERT INTO `link_detail` VALUES (55,15,'a','a',NULL,'a'),(56,15,'b','b',NULL,'b'),(58,24,'JPA개념','JPA소개 및 JPA의 기본동작',NULL,'https://tinkerbellbass.tistory.com/24'),(59,24,'Spring Data JPA 공식 문서','Spring Data JPA 공식 문서',NULL,'https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#preface'),(60,24,'Spring Data JPA 시작 및 설정','시작 및 설정',NULL,'https://goddaehee.tistory.com/209'),(61,24,'JPA Annotation','JPA Annotation, 객체 매핑, 프록시 등등',NULL,'https://m.blog.naver.com/dimigozzang/220510288775'),(62,25,'회원가입 인증 이메일 보내기','Spring에서 이메일 인증 메일 보내기',NULL,'https://moonong.tistory.com/45'),(63,25,'패스워드 암호화 적용','Spring Security 이용하여 패스워드 암호화하기',NULL,'https://youngjinmo.github.io/2021/05/passwordencoder/'),(64,25,'javax mail TLS 설정','메일인증 보낼 때 TLS관련 오류 해결 방법',NULL,'https://heestory217.tistory.com/124'),(65,26,'Spring Security 와 JWT','Spring Security 와 JWT로 로그인 구현',NULL,'https://webfirewood.tistory.com/115'),(66,26,'JWT 이해하기','',NULL,'http://www.opennaru.com/opennaru-blog/jwt-json-web-token/'),(67,26,'Spring Security 기본개념 및 구조','',NULL,'https://devuna.tistory.com/55'),(68,27,'도커이미지를 ec2에 배포하기','',NULL,'https://sas-study.tistory.com/399'),(69,27,'도커 이미지 만드는 방법','',NULL,'https://baeji77.github.io/spring/dev/Spring-boot-gradle-build/'),(70,27,'Dockerfile을 이용한 이미지생성','',NULL,'https://javacan.tistory.com/entry/docker-start-7-create-image-using-dockerfile'),(71,27,'Spring boot 프로젝트 올리기','',NULL,'https://velog.io/@haeny01/AWS-EC2-X-Docker-Spring-Boot-%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8-%EC%98%AC%EB%A6%AC%EA%B8%B0'),(72,28,'Jenkins Pipeline을 활용한 배포 자동화','',NULL,'https://velog.io/@sihyung92/%EC%9A%B0%EC%A0%A0%EA%B5%AC2%ED%8E%B8-%EC%A0%A0%ED%82%A8%EC%8A%A4-%ED%8C%8C%EC%9D%B4%ED%94%84%EB%9D%BC%EC%9D%B8%EC%9D%84-%ED%99%9C%EC%9A%A9%ED%95%9C-%EB%B0%B0%ED%8F%AC-%EC%9E%90%EB%8F%99%ED%99%94'),(73,28,'Jenkins Pipeline이해하기','',NULL,'https://cwal.tistory.com/24'),(74,28,'Pipeline 작성방법','',NULL,'https://parkhyeokjin.github.io/devops/2019/10/14/JekinsWritePipeline.html'),(75,28,'Jenkins 환경 구축하기','',NULL,'https://tecoble.techcourse.co.kr/post/2021-10-10-jenkins/'),(81,29,'상속의 개념','상속의 개념 및 부모/자식 클래스에 대한 정리',NULL,'https://blog.naver.com/PostView.nhn?blogId=heartflow89&logNo=220960019390'),(82,29,'Java 상속 예제','상속 예제로 이해하기/ super & super() 이해하기',NULL,'https://commin.tistory.com/101'),(84,30,'Java Exception 개념','Exception 개념 및 예외처리 개념',NULL,'https://limkydev.tistory.com/198'),(85,30,'Excption 종류와 예외처리','',NULL,'https://chanhuiseok.github.io/posts/java-3/'),(86,30,'Java 예외처리 예제','',NULL,'https://wakestand.tistory.com/98'),(87,30,'예외처리 코드 잘 짜는 법','',NULL,'https://hbase.tistory.com/157'),(88,31,'람다식의 개념!','람다 개념 및 특징',NULL,'https://khj93.tistory.com/entry/JAVA-%EB%9E%8C%EB%8B%A4%EC%8B%9DRambda%EB%9E%80-%EB%AC%B4%EC%97%87%EC%9D%B4%EA%B3%A0-%EC%82%AC%EC%9A%A9%EB%B2%95'),(89,31,'람다식 나무위키','킹무위키',NULL,'https://namu.wiki/w/%EB%9E%8C%EB%8B%A4%EC%8B%9D'),(90,31,'람다 사용법 및 예제','',NULL,'https://hbase.tistory.com/78'),(91,31,'람다 장단점','',NULL,'https://pearlluck.tistory.com/637'),(92,32,'components 와 props 개념','',NULL,'https://mkil.tistory.com/516'),(93,32,'props 사용 예제','',NULL,'https://velog.io/@devmin/Vue.js-props-basic'),(94,32,'Vue props 사용 방법 정리','',NULL,'https://goodmemory.tistory.com/145'),(96,33,'Vue 라우터 개념','',NULL,'https://jinyisland.kr/post/vue-router/'),(97,33,'라우터 설정 및 사용방법','',NULL,'https://webisfree.com/2019-03-25/[vuejs]-vue-router-%EC%82%AC%EC%9A%A9%ED%95%98%EB%8A%94-%EB%B0%A9%EB%B2%95-%EB%9D%BC%EC%9A%B0%ED%8A%B8-%EC%84%A4%EC%A0%95'),(98,33,'Vue 라우터 예제','',NULL,'https://bumcrush.tistory.com/168'),(99,24,'ORM 이란?','ORM 개념',NULL,'https://gmlwjd9405.github.io/2019/02/01/orm.html'),(100,24,'JPA, Hibernate, Spring Data JPA 차이점','',NULL,'https://suhwan.dev/2019/02/24/jpa-vs-hibernate-vs-spring-data-jpa/'),(125,43,'쉽게 볼 수 있는 깃 브랜치 전략','',NULL,'https://hyeon9mak.github.io/git-branch-strategy/'),(126,43,'Git 브랜치의 종류 및 사용법','깃 브랜치 종류 및 사용법',NULL,'https://gmlwjd9405.github.io/2018/05/11/types-of-git-branch.html'),(127,43,'github 로 협업하는 방법','소규모 프로젝트를 위한 feature branch workflow',NULL,'https://gmlwjd9405.github.io/2017/10/27/how-to-collaborate-on-GitHub-1.html'),(128,43,'협업을 위한 git 커밋 컨벤션 설정하기','깃 컨벤션 설정하기',NULL,'https://overcome-the-limits.tistory.com/entry/%ED%98%91%EC%97%85-%ED%98%91%EC%97%85%EC%9D%84-%EC%9C%84%ED%95%9C-%EA%B8%B0%EB%B3%B8%EC%A0%81%EC%9D%B8-git-%EC%BB%A4%EB%B0%8B%EC%BB%A8%EB%B2%A4%EC%85%98-%EC%84%A4%EC%A0%95%ED%95%98%EA%B8%B0'),(129,44,'EC2 MobaXterm SSH 접속방법','SSH 클라이언트 프로그램, 네트워크 상의 다른 컴퓨터에 로그인하거나 원격 시스템에서 명령을 실행하고 다른 시스템으로 파일을 복사할 수 있도록 해주는 응용 프로그램 또는 프로토콜입니다.',NULL,'https://gethlemn.tistory.com/12'),(130,44,'ubuntu 20.04, Nginx 설치 및 이해','',NULL,'https://t-okk.tistory.com/154'),(131,44,'Docker, Nginx 활용 ec2에 프로젝트 배포','',NULL,'https://blog.naver.com/PostView.naver?blogId=jinwoo6612&logNo=222532202235&categoryNo=0&parentCategoryNo=0&viewDate=&currentPage=1&postListTopCurrentPage=1&from=postView'),(132,44,'AWS RDS 사용하기','개인 계정으로 AWS RDS 서버 생성하기',NULL,'https://velog.io/@noyo0123/AWS-RDS-%ED%94%84%EB%A6%AC%ED%8B%B0%EC%96%B4%EB%A1%9C-%EC%82%AC%EC%9A%A9%ED%95%B4%EB%B3%B4%EA%B8%B0-gek2el89jw'),(133,44,'Bastion Host 이해','',NULL,'https://err-bzz.oopy.io/f5616e26-79ca-4167-b2eb-140de69b9b54'),(134,44,'AWS S3 버킷 생성','AWS S3 버킷 생성하기 입니다',NULL,'https://zzang9ha.tistory.com/358'),(135,44,'AWS S3 CORS 설정','S3의 CORS 설정, JSON 방식',NULL,'https://www.enteroa.com/2020/11/05/s3-%EB%B2%84%ED%82%B7-cors-%EC%84%A4%EC%A0%95-json/'),(136,44,'AWS EC2 https 설정','Let\'s Encrypt를 통해 무료로 https 설정하기',NULL,'https://twpower.github.io/44-set-free-https-by-using-letsencrypt'),(140,47,'형상관리란','',NULL,'https://brunch.co.kr/@yoonms/16'),(141,47,'왕초보를 위한 Git 사용법','',NULL,'https://blogger.pe.kr/794'),(142,47,'Git 사용법 정리','',NULL,'https://www.lainyzine.com/ko/article/summary-of-how-to-use-git-for-source-code-management/');
/*!40000 ALTER TABLE `link_detail` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18 11:28:01
