-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: linkshare-01-db.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: lsdb
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `confirm` tinyint(1) NOT NULL DEFAULT '0',
  `auth_key` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `introduce` text,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (12,0,1,'702895','gud_ejr@naver.com','$2a$10$ciX8kFD7.4p.Lt171mZfTOZKaBiiTwX5/nz0ufT11T92FEeCybJni','자바조아','코딩조아','2022-02-06 16:42:46',''),(13,0,0,'768408','gudejr@naver.com','$2a$10$UgP3KO5KjZsEUOESsABcjOMWcRrX2K2csysov8tgbdbXpdEM9Yukm','쿨거맨',NULL,'2022-02-07 08:01:25',NULL),(15,0,1,'370230','test1@naver.com','$2a$10$9OQjR9PiPDZOdl2aJdLP9.GB./WfSN1wOnHO1INWeMKpCDvZs5Dre','test1',NULL,'2022-02-14 11:02:34',NULL),(16,0,1,'654908','test2@naver.com','$2a$10$QT9PxUkTJqQPpCQG4nIZGe9ELgMqFRDcEukHHJd9wpEoq9Nvvp7Ge','test2',NULL,'2022-02-14 11:02:41',NULL),(17,0,1,'262287','dw3624@gmail.com','$2a$10$gnk3XdTHZfX6yIrDBv1QMeppfRhdIfqvBj86i9yBSK6cTnporc4fO','유저1','안녕하세요. 유저1입니다.','2022-02-14 11:18:33','http://linkshare-01-s3.s3-website.ap-northeast-2.amazonaws.com/user/55100fcb-5fac-4166-ba17-a6231f01c75e-zipper.png'),(18,0,0,'310023','dddd@naver.com','$2a$10$r1IRwelhWz.CsOgGISbFduwnyT6DhxlUYmMhvHWJONNn6Au84hyYO','ghost',NULL,'2022-02-15 10:56:38',NULL),(19,0,0,'922482','won@gmail.com','$2a$10$CnlrnRDxK4IG1cHlwQI4NOLUrDMgIdl8yIDfxFAAZ1sbwlWL/xCTG','wonwon','백엔드 개발자','2022-02-15 16:11:29','http://linkshare-01-s3.s3-website.ap-northeast-2.amazonaws.com/user/58234648-2584-4239-b0c5-b1e0b106eb73-197454740_921634408688626_805215852941839149_n.jpg'),(20,0,0,'467182','wonsic@gmail.com','$2a$10$/5T.YES7L6TONit3TQxoL.3LKWjxb9EMzlc/rZ9Fwbif/7WennnW.','뉴비입니다','초보 개발자입니다','2022-02-16 16:21:32',NULL),(21,0,0,'612607','ILikeYou@naver.com','$2a$10$zxXqj1BC9B9htWlju/YcaukEFHQ0N/6wnuW01GggrGjpj5fYdtlAe','좋아요귀신',NULL,'2022-02-16 17:19:21',NULL),(22,0,0,'225661','world@gmail.com','$2a$10$cQ3lkcsXDRZxjwRIU/GMHOZUbTt.gJBGFvPZPebFPGj1/wfRa5y.m','세상에','프론트엔드 개발자를 꿈꾸고 있습니다!','2022-02-16 17:26:42',NULL),(23,0,0,'391436','hello@naver.com','$2a$10$olKlE3FtoN8QwPMFevTqOuPj03t1lOwKcTyi43loV0onexeOfV4K6','링쉐',NULL,'2022-02-17 05:17:33',NULL),(24,0,0,'779955','linkoo@naver.com','$2a$10$F3a0hk22OiDcfqBHBUZ2BORfRyHP0PX84NCgnIdJXAqTFxD9CgGSe','링쿠','눕는 걸 좋아하는 사람입니다','2022-02-17 05:32:48',NULL),(25,0,0,'472505','sky@naver.com','$2a$10$QJHVcHE2Hl5G9nvF73kbVOW4tP7Tm2WljKdKCXvXvRwu8eG.sIM/.','하늘',NULL,'2022-02-17 15:47:51',NULL),(26,0,0,'116375','dd@naver.com','$2a$10$eACPzhvLq6z5oker8yP/1.dtfA8JhMQtsJFJ9WOw1fDG1v3ZmuaM2','개똥이',NULL,'2022-02-17 16:11:10',NULL),(27,0,0,'762992','moba@gmail.com','$2a$10$faRDTB3XEiqv.F40BmnXaeQ5uWHRhWOlBe9gTnuFjy1Q9D9qt5Q2.','moba',NULL,'2022-02-17 16:14:32',NULL),(28,0,0,'150188','kang0905@gmail.com','$2a$10$8i1rPk8chZMteLJn2Jxt3OHe.57AH6G/4GFD2PaW.PYoTQAZnn/Ty','강낭콩가난콘',NULL,'2022-02-17 16:16:15',NULL),(29,0,0,'979972','test@naver.com','$2a$10$8lEqOrKMSUlp620TSmrcSugIwH8YxhasabaLIP4v3LEijXIgYJeR6','넹넹',NULL,'2022-02-17 18:03:49',NULL),(30,0,0,'921148','j103607@gmail.com','$2a$10$N.52dkN4BJ/GLEKgnuwULO00EP8T5uqY157M9NPWIlGmsGCZApn9u','슬민',NULL,'2022-02-18 01:50:17',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18 11:28:01
