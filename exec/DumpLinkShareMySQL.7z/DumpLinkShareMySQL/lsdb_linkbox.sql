-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: linkshare-01-db.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: lsdb
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `linkbox`
--

DROP TABLE IF EXISTS `linkbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `linkbox` (
  `boxid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `view_count` int NOT NULL DEFAULT '0',
  `desc` text,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linkbox`
--

LOCK TABLES `linkbox` WRITE;
/*!40000 ALTER TABLE `linkbox` DISABLE KEYS */;
INSERT INTO `linkbox` VALUES (24,'JPA 학습할 때 참고한 링크',163,'Spring boot 를 이용하여 웹 서비스 백엔드를 개발할 때 참고하였습니다.','2022-02-16 19:29:03'),(25,'회원가입 구현한 링크',123,'Spring boot로 회원가입 구현할 때 참고했습니다~','2022-02-16 20:18:21'),(26,'로그인 참고',88,'Spring Security + 로그인 구현시 참고했습니다~','2022-02-16 20:53:04'),(27,'AWS, Docker에 대한 링크',56,'(스프링부트 혹은 vue) 프로젝트를 docker 이미지를 통해서 AWS 에 배포하는 것에 대해 참고하였습니다.','2022-02-16 22:23:42'),(28,'배포 자동화 참고 링크',36,'젠킨스 파이프라인을 활용한 배포 자동화를 학습할 때 참고한 링크들 입니다!','2022-02-16 22:46:32'),(29,'Java의 상속',30,'Java에서 상속 개념 공부할 때 참고했어요','2022-02-17 01:44:54'),(30,'Java의 예외처리(Exception)',47,'예외처리 관련 링크입니다!!','2022-02-17 02:06:54'),(31,'Java 람다식 링크',24,'Lambda 공부할 때 도움 정말 많이 되었어요!','2022-02-17 02:13:26'),(32,'Vue.js, props 데이터 전달 관련 링크',39,'props 공부할 때 아주 좋아요','2022-02-17 02:28:48'),(33,'Vue 라우터 관련 링크',15,'라우터 완전 정복','2022-02-17 02:44:23'),(43,'Git 전략',0,'Git 브랜치, 커밋 전략','2022-02-18 10:08:16'),(44,'AWS EC2, RDS, S3 세팅',0,'AWS EC2, RDS, S3 세팅하는 방법입니다','2022-02-18 10:11:54'),(46,'공통 프로젝트 참고자료',0,'','2022-02-18 10:51:11'),(47,'형상관리와 깃에 대한 링크',0,'왕초보를 위한  Git 링크 입니다!!','2022-02-18 10:52:31');
/*!40000 ALTER TABLE `linkbox` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18 11:28:01
