-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: linkshare-01-db.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: lsdb
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `interest`
--

DROP TABLE IF EXISTS `interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest` (
  `interest_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`interest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest`
--

LOCK TABLES `interest` WRITE;
/*!40000 ALTER TABLE `interest` DISABLE KEYS */;
INSERT INTO `interest` VALUES (1,'SpringBoot','2022-02-03 01:03:20'),(2,'JPA','2022-02-03 01:03:20'),(3,'Docker','2022-02-03 03:17:04'),(4,'ㅁ','2022-02-10 21:33:03'),(5,'ㄱ','2022-02-10 21:34:25'),(6,'test','2022-02-13 17:34:33'),(7,'자고싶다','2022-02-15 01:07:04'),(8,'나도 자고싶어','2022-02-15 01:13:47'),(9,'진짜 자고싶다','2022-02-14 18:00:09'),(10,'a','2022-02-15 03:42:09'),(11,'b','2022-02-15 03:42:15'),(12,'c','2022-02-15 03:43:50'),(13,'HTML','2022-02-15 05:42:06'),(14,'Java','2022-02-15 05:42:06'),(15,'Python','2022-02-15 06:04:22'),(16,'Django','2022-02-15 06:19:00'),(17,'CSS','2022-02-15 06:24:19'),(18,'사슴','2022-02-15 06:28:36'),(19,'토끼','2022-02-15 06:29:37'),(20,'vue.js','2022-02-15 06:49:13'),(21,'고릴라','2022-02-15 08:02:12'),(22,'거북이','2022-02-15 08:02:55'),(23,'양송이','2022-02-15 08:02:55'),(24,'백작','2022-02-15 15:38:00'),(25,'동원님 화이팅','2022-02-15 16:25:50'),(26,'원식님 화이팅','2022-02-15 16:30:32'),(27,'새벽2시','2022-02-15 17:01:22'),(28,'죽여줘','2022-02-15 17:01:22'),(29,'살려줘','2022-02-15 17:16:51'),(30,'aws','2022-02-16 10:00:21'),(31,'프로그래밍','2022-02-16 10:07:28'),(32,'개발자','2022-02-16 10:07:28'),(33,'Spring','2022-02-16 10:29:02'),(34,'Spring boot','2022-02-16 11:18:21'),(35,'JWT','2022-02-16 11:53:04'),(36,'Vue','2022-02-16 13:08:05'),(37,'React','2022-02-16 13:08:05'),(38,'Jenkins','2022-02-16 13:17:52'),(39,'DevOps','2022-02-16 13:17:52'),(40,'CD','2022-02-16 13:46:31'),(41,'JavaScript','2022-02-16 16:44:53'),(42,'Lambda','2022-02-16 17:13:26'),(43,'props','2022-02-16 17:28:48'),(44,'hibernate','2022-02-16 18:56:18'),(45,'ORM','2022-02-16 18:56:29'),(46,'Git','2022-02-17 08:27:04'),(47,'GitHub','2022-02-17 08:27:04'),(48,'형상관리','2022-02-17 08:27:04'),(49,'EC2','2022-02-18 01:12:09'),(50,'RDS','2022-02-18 01:12:09'),(51,'S3','2022-02-18 01:12:09');
/*!40000 ALTER TABLE `interest` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18 11:28:03
